package com.examp.shoppingOnline;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class DboOperate {
	public void save(Object obj) throws HibernateException{
		Session session = HibernanteUtil.currentSession();
		if (obj !=null){
			Transaction tx = null;
			try{
				tx = session.beginTransaction();
				session.save(obj);
				tx.commit();
			}catch (HibernateException e){
				if (tx !=null)
					tx.rollback();
				throw e;
			}
		}
		session.close();
	}
   public void update(Object obj) throws HibernateException{
	   Session session =HibernanteUtil.currentSession();
	   if(obj != null){
		   Transaction tx=null;
		   try{
		   tx=session.beginTransaction();
		   session.update(obj);
		   tx.commit();
		   } catch (HibernateException e){
			   if(tx !=null){
				   tx.rollback();
				   throw e;
			   }
		   }
		   session.close();
		   }
				   
	   }
	   public void delete(Object obj) throws HibernateException{
		   Session session =HibernanteUtil.currentSession();
		   if(obj != null){
			   Transaction tx=null;
			   try{
			   tx=session.beginTransaction();
			   session.delete(obj);
			   tx.commit();
			   } catch (HibernateException e){
				   if(tx !=null){
					   tx.rollback();
					   throw e;
				   }
			   }
			   session.close();
	   }
		
	}

}
