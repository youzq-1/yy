package com.examp.shoppingOnline;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.examp.shopping.Category;

public class CategoryOperator {
	public List<Category> getCategories() throws HibernateException {
		Session session =HibernanteUtil.currentSession();
		String hql="from Category";
		Query query=session.createQuery(hql);
		List<Category> list=query.list();
		return list;
	}
	//����������ѯ����
    public Category getCategory(int id){
    	Session session = HibernanteUtil.currentSession();
    	Category category = (Category) session.load(Category.class, id);
    	return category;
    }
}
