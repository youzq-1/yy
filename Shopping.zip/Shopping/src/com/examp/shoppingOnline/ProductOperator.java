package com.examp.shoppingOnline;

import java.util.List;


import org.hibernate.Query;
import org.hibernate.Session;


import com.examp.shopping.Product;

public class ProductOperator {
	public List<Product> getProducts(){
		Session session =HibernanteUtil.currentSession();
		String hql="from Product";
		Query query=session.createQuery(hql);
		List<Product> list=query.list();
		return list;
	}
	
	//��ѯָ����Ʒ���Ƶ���Ʒ��Ϣ
	public List<Product> getProduct(String name){
		Session session= HibernanteUtil.currentSession();
		String hql="from Product where name=?";
		Query query=session.createQuery(hql);
		query.setString(0, name);
		List<Product>list=query.list();
		
		return list;
	}
	
	public Product getProduct(int id) {
		//����һ
		Session session= HibernanteUtil.currentSession();
		String hql="from Product where id=?";
		Query query=session.createQuery(hql);
		query.setInteger(0, id);
		List<Product>list=query.list();
		
		if(list.size()>0) {
			return list.get(0);
		} else {
			return null;
		}
		//������
		//session.load(id);
	}
}
