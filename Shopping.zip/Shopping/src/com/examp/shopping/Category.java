package com.examp.shopping;

import java.util.HashSet;
import java.util.Set;

public class Category {
	private int id;
	private String name;
	private Set<Product> product;
	
	public Set<Product> getProduct() {
		if(this.product==null)
			this.product = new HashSet();
		return product;
	}
	public void setProduct(Set<Product> product) {
		this.product = product;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
}
