package com.examp.shopping;

import java.util.Set;

public class User {
	private int id;
	private String userName;
	private String passWord;
	private String realName;
	private String tel;
	private String address;
	private String zip;
	private String email;
	
	private Credit_Card_Account credit_card_account;

	
	public Credit_Card_Account getCredit_card_account() {
		return credit_card_account;
	}
	public void setCredit_card_account(Credit_Card_Account credit_card_account) {
		this.credit_card_account = credit_card_account;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
